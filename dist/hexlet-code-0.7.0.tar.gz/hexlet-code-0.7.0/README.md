### Hexlet tests and linter status:
[![Actions Status](https://github.com/arisesinmight/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/arisesinmight/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/c777c42d524002db4529/maintainability)](https://codeclimate.com/github/arisesinmight/python-project-49/maintainability)

[![asciicast](https://asciinema.org/a/520294.svg)](https://asciinema.org/a/520294)

[![asciicast](https://asciinema.org/a/23oQs7DXtHDTSYSsWIX4oGCWF.svg)](https://asciinema.org/a/23oQs7DXtHDTSYSsWIX4oGCWF)

[![asciicast](https://asciinema.org/a/xsJg4ZdSPPB3oLwfg0iTZdTCS.svg)](https://asciinema.org/a/xsJg4ZdSPPB3oLwfg0iTZdTCS)

[![asciicast](https://asciinema.org/a/CGlfmvAz5PRO2HL3yV2Amb2qJ.svg)](https://asciinema.org/a/CGlfmvAz5PRO2HL3yV2Amb2qJ)
