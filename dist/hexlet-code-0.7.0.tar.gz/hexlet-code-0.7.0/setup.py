# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0', 'sympy>=1.11.1,<2.0.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:brain_calc',
                     'brain-even = brain_games.scripts.brain_even:brain_even',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:brain_gcd',
                     'brain-prime = '
                     'brain_games.scripts.brain_prime:brain_prime',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:brain_progression']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.7.0',
    'description': '',
    'long_description': 'Hexlet brain games project contains different logical games:\n\n\n   is_even: In wich you should answer if random number is even\n   \n   calculator: In wich you should solve random arithmetical expressions\n   \n   gcd: In wich you should find out the greatest common divisor of two random numbers\n   \n   progression: In wich you should find out the missing part of random arithmetical progression\n   \n   is prime: In wich you should answer if random number is prime\n\nProgramm runs on UNIX and MAC systems, to run on Windows use WSL\n\nTo install:\nClone repository and being in its root(python-project-49) run "make install-package", or if you don\'t use "make" utility, run "python3 -m pip install --user dist/*.whl". You will still need to have "python 3" and "pip" to be installed in your system.\n    \n\nTo run games use:\n\n\nbrain-even \n\nbrain-calc \n\nbrain-gcd \n\nbrain-progression \n\nbrain-prime\n\n\n### Hexlet tests and linter status:\n[![Actions Status](https://github.com/arisesinmight/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/arisesinmight/python-project-49/actions)\n\n[![Maintainability](https://api.codeclimate.com/v1/badges/c777c42d524002db4529/maintainability)](https://codeclimate.com/github/arisesinmight/python-project-49/maintainability)\n\n[![asciicast](https://asciinema.org/a/520294.svg)](https://asciinema.org/a/520294)\n\n[![asciicast](https://asciinema.org/a/23oQs7DXtHDTSYSsWIX4oGCWF.svg)](https://asciinema.org/a/23oQs7DXtHDTSYSsWIX4oGCWF)\n\n[![asciicast](https://asciinema.org/a/xsJg4ZdSPPB3oLwfg0iTZdTCS.svg)](https://asciinema.org/a/xsJg4ZdSPPB3oLwfg0iTZdTCS)\n\n[![asciicast](https://asciinema.org/a/CGlfmvAz5PRO2HL3yV2Amb2qJ.svg)](https://asciinema.org/a/CGlfmvAz5PRO2HL3yV2Amb2qJ)\n\n[![asciicast](https://asciinema.org/a/rOc2CR8iqm8hPqC2Z9HlAaZEU.svg)](https://asciinema.org/a/rOc2CR8iqm8hPqC2Z9HlAaZEU)\n',
    'author': 'Pavel Ilchenko',
    'author_email': 'arisesinmight@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
