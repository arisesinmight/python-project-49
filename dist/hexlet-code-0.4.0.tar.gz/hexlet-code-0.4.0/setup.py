# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:brain_calc',
                     'brain-even = brain_games.scripts.brain_even:brain_even',
                     'brain-games = brain_games.scripts.brain_games:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.4.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/arisesinmight/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/arisesinmight/python-project-49/actions)\n\n[![Maintainability](https://api.codeclimate.com/v1/badges/c777c42d524002db4529/maintainability)](https://codeclimate.com/github/arisesinmight/python-project-49/maintainability)\n\n[![asciicast](https://asciinema.org/a/520294.svg)](https://asciinema.org/a/520294)\n',
    'author': 'Pavel Ilchenko',
    'author_email': 'arisesinmight@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
